package com.example.jpapagingsortingfiltering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaPagingSortingFilteringApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaPagingSortingFilteringApplication.class, args);
	}

}
