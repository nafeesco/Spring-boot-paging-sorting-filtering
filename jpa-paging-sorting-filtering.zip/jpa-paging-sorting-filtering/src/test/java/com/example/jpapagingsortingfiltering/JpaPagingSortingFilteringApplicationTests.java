package com.example.jpapagingsortingfiltering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaPagingSortingFilteringApplicationTests {

	@Test
	void contextLoads() {
	}

}
